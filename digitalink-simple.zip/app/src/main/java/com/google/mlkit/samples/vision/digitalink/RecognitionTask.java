package com.google.mlkit.samples.vision.digitalink;

import android.util.Log;

import androidx.annotation.Nullable;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.digitalink.DigitalInkRecognizer;
import com.google.mlkit.vision.digitalink.Ink;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Task to run asynchronously to obtain recognition results.
 */
public class RecognitionTask {

    private static final String TAG = "MLKD.RecognitionTask";
    private final DigitalInkRecognizer recognizer;
    private final Ink ink;
    @Nullable
    private RecognizedInk currentResult;
    private final AtomicBoolean cancelled;
    private final AtomicBoolean done;

    //這個構造函數的目的是設定識別任務的初始狀態。
    public RecognitionTask(DigitalInkRecognizer recognizer, Ink ink) {
        //將傳入的 recognizer 參數賦值給實例變數 this.recognizer。這樣 RecognitionTask 類的實例就可以使用這個識別器進行識別操作。
        this.recognizer = recognizer;
        //將傳入的 ink 參數賦值給實例變數 this.ink。這樣 RecognitionTask 類的實例就知道要處理哪個墨水對象。
        this.ink = ink;
        //初始化實例變數 currentResult 為 null。currentResult 可能用來存儲識別操作的結果，初始時沒有結果，因此設為 null。
        this.currentResult = null;
        //使用 AtomicBoolean 類來創建 cancelled 變數，並初始化為 false。AtomicBoolean 是一個支持原子操作的布爾變量，常用於多線程環境下的狀態管理。這個變數表示識別任務是否被取消。
        cancelled = new AtomicBoolean(false);
        //同樣，使用 AtomicBoolean 類來創建 done 變數，並初始化為 false。這個變數表示識別任務是否已完成。
        done = new AtomicBoolean(false);
    }

    public void cancel() {
        cancelled.set(true);
    }

    public boolean done() {
        return done.get();
    }

    @Nullable
    public RecognizedInk result() {
        return this.currentResult;
    }

    /**
     * Helper class that stores an ink along with the corresponding recognized text.
     */
    public static class RecognizedInk {
        public final Ink ink;
        public final String text;

        RecognizedInk(Ink ink, String text) {
            this.ink = ink;
            this.text = text;
        }
    }

    //它用於執行識別任務並返回一個 Task<String>。這個方法利用了 recognizer 來處理墨水對象 (ink)，並根據識別結果進行後續處理。
    public Task<String> run() {
        Log.i(TAG, "RecoTask.run");
        //調用 recognizer 的 recognize 方法來識別傳入的 ink 對象。這個方法會返回一個 Task，表示識別操作的結果。
        return recognizer
                .recognize(this.ink)
                .onSuccessTask(
                        result -> {
                            //檢查識別任務是否被取消 (cancelled.get()) 或者識別結果中沒有候選項 (result.getCandidates().isEmpty())。如果是這兩種情況之一，返回一個表示沒有結果的 Task (Tasks.forResult(null))，這樣後續處理可以知道識別操作未能成功。
                            if (cancelled.get() || result.getCandidates().isEmpty()) {
                                return Tasks.forResult(null);
                            }
                            //創建一個 RecognizedInk 對象，將識別的結果存儲在 currentResult 中。RecognizedInk 類可能是用來封裝識別結果的對象。
                            currentResult = new RecognizedInk(ink, result.getCandidates().get(0).getText());
                            Log.i(TAG, "result: " + currentResult.text);
                            //設置 done 為 true，表示識別任務已完成。這個變數是 AtomicBoolean 類型，用於在多線程環境下安全地更新狀態。
                            done.set(true);
                            //返回一個表示識別結果的 Task，其結果是 currentResult.text。這樣調用 run 方法的地方可以獲得識別操作的最終結果。
                            return Tasks.forResult(currentResult.text);
                        });
    }
}
