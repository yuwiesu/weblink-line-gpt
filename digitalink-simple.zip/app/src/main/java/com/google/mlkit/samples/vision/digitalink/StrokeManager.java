package com.google.mlkit.samples.vision.digitalink;

import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;

import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.digitalink.Ink;
import com.google.mlkit.vision.digitalink.Ink.Point;

import java.util.ArrayList;
import java.util.List;

/**
 * Manages the recognition logic and the content that has been added to the current page.
 */
public class StrokeManager {

    /**
     * Interface to register to be notified of changes in the recognized content.
     */
    public interface ContentChangedListener {

        /**
         * This method is called when the recognized content changes.
         */
        void onContentChanged();
    }

    @VisibleForTesting
    static final long CONVERSION_TIMEOUT_MS = 1000;
    private static final String TAG = "MLKD.StrokeManager";
    // This is a constant that is used as a message identifier to trigger the timeout.
    private static final int TIMEOUT_TRIGGER = 1;
    // For handling recognition and model downloading.
    private RecognitionTask recognitionTask = null;
    @VisibleForTesting
    ModelManager modelManager = new ModelManager();
    // Managing the recognition queue.
    private final List<RecognitionTask.RecognizedInk> content = new ArrayList<>();
    // Managing ink currently drawn.
    private Ink.Stroke.Builder strokeBuilder = Ink.Stroke.builder();
    private Ink.Builder inkBuilder = Ink.builder();
    private boolean stateChangedSinceLastRequest = false;
    @Nullable
    private ContentChangedListener contentChangedListener = null;

    private boolean triggerRecognitionAfterInput = true;
    private boolean clearCurrentInkAfterRecognition = true;

    //是否在輸入後觸發識別
    public void setTriggerRecognitionAfterInput(boolean shouldTrigger) {
        triggerRecognitionAfterInput = shouldTrigger;
    }

    //是否在識別後清除當前墨水
    public void setClearCurrentInkAfterRecognition(boolean shouldClear) {
        clearCurrentInkAfterRecognition = shouldClear;
    }

    //這段程式碼的目的是處理超時觸發事件。
    private final Handler uiHandler =
            new Handler(
                    msg -> {
                        if (msg.what == TIMEOUT_TRIGGER) {
                            Log.i(TAG, "Handling timeout trigger.");
                            commitResult();
                            return true;
                        }

                        return false;
                    });

    //用於處理識別任務完成後的結果。它檢查識別任務是否完成，處理結果，更新狀態，並根據需要執行其他操作，如清除當前墨水和通知內容變更。
    private void commitResult() {
        if (recognitionTask.done() && recognitionTask.result() != null) {
            //將識別任務的結果添加到 content 集合中。content 可能是一個列表或其他集合，用來存儲識別結果。
            content.add(recognitionTask.result());
            //更新狀態，顯示識別成功的信息。
//      setStatus("Successful recognition: " + recognitionTask.result().text);
            if (clearCurrentInkAfterRecognition) {
                //清除當前墨水。這個方法通常用於重置或清除當前的繪圖或輸入內容。
                resetCurrentInk();
            }
            if (contentChangedListener != null) {
                //通知內容變更。
                contentChangedListener.onContentChanged();
            }
        }
    }

    //這個方法主要用於重置當前的繪圖或輸入狀態、清空內容、取消未完成的識別任務，以及更新狀態。
    public void reset() {
        Log.i(TAG, "reset");
        //重置當前墨水。這通常用於清除或重置當前的繪圖或輸入內容。
        resetCurrentInk();
        //content 可能是一個列表或其他集合，用來存儲識別結果或其他相關數據。
        content.clear();
        if (recognitionTask != null && !recognitionTask.done()) {
            //這可以用來停止任何正在進行的識別操作，避免不必要的處理或資源浪費。
            recognitionTask.cancel();
        }
    }

    //重置當前的墨水和相關的繪圖狀態。
    private void resetCurrentInk() {
        inkBuilder = Ink.builder();
        strokeBuilder = Ink.Stroke.builder();
        //重置狀態變化的跟蹤標誌。
        stateChangedSinceLastRequest = false;
    }

    //用於獲取當前的 Ink 對象。
    public Ink getCurrentInk() {
        return inkBuilder.build();
    }

    //用於處理觸摸事件。該方法根據觸摸事件的類型（如點擊、移動、抬起）來更新 Ink 對象的狀態，並在必要時觸發識別操作。
    public boolean addNewTouchEvent(MotionEvent event) {
        //用於獲取不受多點觸控影響的動作類型。
        int action = event.getActionMasked();
        float x = event.getX();
        float y = event.getY();
        //獲取當前系統時間的毫秒數，表示事件發生的時間戳。
        long t = System.currentTimeMillis();

        // A new event happened -> clear all pending timeout messages.
        //移除所有與 TIMEOUT_TRIGGER 相關的消息。這樣做是為了清除之前設置的超時消息，以防止在處理新事件時超時處理。
        uiHandler.removeMessages(TIMEOUT_TRIGGER);

        switch (action) {
            case MotionEvent.ACTION_DOWN: //用於處理觸摸事件開始時的情況（例如點擊）。
            case MotionEvent.ACTION_MOVE: //用於處理觸摸點移動時的情況。
                strokeBuilder.addPoint(Point.create(x, y, t));
                break;
            case MotionEvent.ACTION_UP: //用於處理觸摸點抬起的情況。
                strokeBuilder.addPoint(Point.create(x, y, t));
                inkBuilder.addStroke(strokeBuilder.build());
                strokeBuilder = Ink.Stroke.builder();
                stateChangedSinceLastRequest = true;
                if (triggerRecognitionAfterInput) {
                    recognize();
                }
                break;
            default:
                // Indicate touch event wasn't handled.
                return false;
        }
        return true;
    }

    // Listeners to update the drawing and status.
    public void setContentChangedListener(ContentChangedListener contentChangedListener) {
        this.contentChangedListener = contentChangedListener;
    }

    public List<RecognitionTask.RecognizedInk> getContent() {
        return content;
    }

    public Task<Void> download() {
        return modelManager
                .download()
                .onSuccessTask(
                        status -> {
                            return Tasks.forResult(null);
                        });
    }

    // Recognition-related.
    //用於執行墨水識別操作。該方法檢查狀態是否已經改變，並且確保模型已經下載，然後創建並運行一個識別任務。
    public Task<String> recognize() {
        modelManager.setModel("zh-Hani-TW");
        download();
        return modelManager
                .checkIsModelDownloaded()
                .onSuccessTask(
                        result -> {
                            if (!result) {
                                return Tasks.forResult(null);
                            }

                            stateChangedSinceLastRequest = false;
                            recognitionTask =
                                    new RecognitionTask(modelManager.getRecognizer(), inkBuilder.build());
                            uiHandler.sendMessageDelayed(
                                    uiHandler.obtainMessage(TIMEOUT_TRIGGER), CONVERSION_TIMEOUT_MS);
                            return recognitionTask.run();
                        });
    }
}
