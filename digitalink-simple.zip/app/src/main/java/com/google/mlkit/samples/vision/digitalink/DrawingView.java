package com.google.mlkit.samples.vision.digitalink;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;

import com.google.mlkit.samples.vision.digitalink.StrokeManager.ContentChangedListener;
import com.google.mlkit.vision.digitalink.Ink;

import java.util.List;

/**
 * Main view for rendering content.
 *
 * <p>The view accepts touch inputs, renders them on screen, and passes the content to the
 * StrokeManager. The view is also able to draw content from the StrokeManager.
 */
public class DrawingView extends View implements ContentChangedListener {
    private static final String TAG = "MLKD.DrawingView";
    private static final int STROKE_WIDTH_DP = 3;
    private static final int MIN_BB_WIDTH = 10;
    private static final int MIN_BB_HEIGHT = 10;
    private static final int MAX_BB_WIDTH = 256;
    private static final int MAX_BB_HEIGHT = 256;

    private final Paint recognizedStrokePaint;
    private final TextPaint textPaint;
    private final Paint currentStrokePaint;
    private final Paint canvasPaint;

    private final Path currentStroke;
    private Canvas drawCanvas;
    private Bitmap canvasBitmap;
    private StrokeManager strokeManager;

    public DrawingView(Context context) {
        this(context, null);
    }

    //初始化畫筆（Paint）和其他繪圖屬性
    public DrawingView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        currentStrokePaint = new Paint();
        currentStrokePaint.setColor(0xFF64dcf0); // pink.
        currentStrokePaint.setAntiAlias(true);
        // Set stroke width based on display density. 設置筆觸的寬度。
        currentStrokePaint.setStrokeWidth(
                TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP, STROKE_WIDTH_DP, getResources().getDisplayMetrics()));
        //設置畫筆的樣式為 STROKE，這表示畫筆將只繪製邊框而不是填充整個區域。
        currentStrokePaint.setStyle(Paint.Style.STROKE);
        //設置筆觸的連接處樣式為 ROUND，這樣筆觸之間的交接處將以圓角樣式顯示。
        currentStrokePaint.setStrokeJoin(Paint.Join.ROUND);
        //設置筆觸的末端樣式為 ROUND，這樣筆觸的端點將以圓角樣式顯示。
        currentStrokePaint.setStrokeCap(Paint.Cap.ROUND);
        //創建一個新的 Paint 對象 recognizedStrokePaint，並使用 currentStrokePaint 的設置進行初始化。
        recognizedStrokePaint = new Paint(currentStrokePaint);
        recognizedStrokePaint.setColor(0xFFFFCCFF); // smart blue.
        //創建一個新的 TextPaint 對象，用於繪製文本。
        textPaint = new TextPaint();
        //設置文本畫筆的顏色
        textPaint.setColor(0xFF005087); // auo blue.
        //創建一個新的 Path 對象，用於存儲和操作當前筆觸的路徑。
        currentStroke = new Path();
        //創建一個新的 Paint 對象 canvasPaint，並啟用抖動標誌 (DITHER_FLAG)，這可以在顯示顏色過渡時提供更好的效果。
        canvasPaint = new Paint(Paint.DITHER_FLAG);
    }

    //用於計算並返回一個矩形（Rect），這個矩形包圍了傳入的 Ink 對象中的所有筆觸。
    private static Rect computeBoundingBox(Ink ink) {
        float top = Float.MAX_VALUE;
        float left = Float.MAX_VALUE;
        float bottom = Float.MIN_VALUE;
        float right = Float.MIN_VALUE;
        //遍歷 Ink 對象中的每個筆觸 (Stroke 對象)
        for (Ink.Stroke s : ink.getStrokes()) {
            //遍歷每個筆觸中的所有點 (Point 對象)。
            for (Ink.Point p : s.getPoints()) {
                //找到所有點中的最小 Y 值，即最上方的位置。
                top = Math.min(top, p.getY());
                //找到所有點中的最小 X 值，即最左邊的位置。
                left = Math.min(left, p.getX());
                //找到所有點中的最大 Y 值，即最下方的位置。
                bottom = Math.max(bottom, p.getY());
                //找到所有點中的最大 X 值，即最右邊的位置。
                right = Math.max(right, p.getX());
            }
        }
        //計算邊界框的中心 X 坐標。
        float centerX = (left + right) / 2;
        //計算邊界框的中心 Y 坐標。
        float centerY = (top + bottom) / 2;
        //創建一個 Rect 對象 bb，表示根據 left、top、right 和 bottom 計算出的初步邊界框。
        Rect bb = new Rect((int) left, (int) top, (int) right, (int) bottom);
        // Enforce a minimum size of the bounding box such that recognitions for small inks are readable
        //使用 union 方法擴展 bb 的大小，確保邊界框至少具有指定的最小寬度 (MIN_BB_WIDTH) 和高度 (MIN_BB_HEIGHT)。這樣可以確保識別結果對於小的 Ink 也能保持可讀性。
        bb.union(
                (int) (centerX - MIN_BB_WIDTH / 2),
                (int) (centerY - MIN_BB_HEIGHT / 2),
                (int) (centerX + MIN_BB_WIDTH / 2),
                (int) (centerY + MIN_BB_HEIGHT / 2));
        // Enforce a maximum size of the bounding box, to ensure Emoji characters get displayed
        // correctly
        //如果邊界框的寬度超過 MAX_BB_WIDTH，則調整邊界框的寬度，保持中心點不變，限制最大寬度。
        if (bb.width() > MAX_BB_WIDTH) {
            bb.set(bb.centerX() - MAX_BB_WIDTH / 2, bb.top, bb.centerX() + MAX_BB_WIDTH / 2, bb.bottom);
        }
        //如果邊界框的高度超過 MAX_BB_HEIGHT，則調整邊界框的高度，保持中心點不變，限制最大高度。
        if (bb.height() > MAX_BB_HEIGHT) {
            bb.set(bb.left, bb.centerY() - MAX_BB_HEIGHT / 2, bb.right, bb.centerY() + MAX_BB_HEIGHT / 2);
        }
        //返回計算好的邊界框 bb。
        return bb;
    }

    void setStrokeManager(StrokeManager strokeManager) {
        this.strokeManager = strokeManager;
    }

    //用於處理視圖尺寸變化的情況。
    @Override
    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        Log.i(TAG, "onSizeChanged");
        //創建一個新的 Bitmap 對象 canvasBitmap。這個位圖的尺寸是視圖的新寬度和高度。Bitmap.Config.ARGB_8888 是位圖的顏色配置，表示每個像素用 4 個字節來存儲，分別是 Alpha、Red、Green 和 Blue 值，這樣可以提供高品質的顏色表示。
        canvasBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        //創建一個新的 Canvas 對象 drawCanvas，並將其與剛才創建的 canvasBitmap 關聯。這樣你可以在 drawCanvas 上進行繪圖操作，而實際的繪圖內容會被畫到 canvasBitmap 上。
        drawCanvas = new Canvas(canvasBitmap);
        //標記視圖需要重繪。這會觸發 onDraw 方法被調用，從而將所有新的繪圖內容渲染到畫布上。
        invalidate();
    }

    //用於重新繪製視圖的內容。這個方法會清除當前顯示的內容，然後根據 strokeManager 提供的最新筆觸和識別結果來繪製新的內容。最終，通過調用 invalidate() 來刷新視圖。
    public void redrawContent() {
        //清除當前的繪圖內容。
        clear();
        //從 strokeManager 獲取當前的筆觸對象（Ink）。strokeManager 是用來管理繪圖筆觸的對象，getCurrentInk() 方法返回當前需要繪製的筆觸。
        Ink currentInk = strokeManager.getCurrentInk();
        //調用 drawInk 方法來繪製當前的筆觸。這裡使用 currentStrokePaint 來設置繪圖樣式。currentStrokePaint 是用於繪製當前筆觸的畫筆對象。
        drawInk(currentInk, currentStrokePaint);

        //獲取 strokeManager 中所有的繪圖內容，這些內容是經過識別的筆觸，存儲在 List<RecognitionTask.RecognizedInk> 中。每個 RecognizedInk 對象包含了識別出的筆觸和文本。
        List<RecognitionTask.RecognizedInk> content = strokeManager.getContent();
        //遍歷 content 列表中的每個 RecognizedInk 對象。ri 代表當前遍歷的 RecognizedInk 對象。
        for (RecognitionTask.RecognizedInk ri : content) {
            //使用 recognizedStrokePaint 繪製識別出的筆觸 ri.ink。recognizedStrokePaint 是用於繪製識別筆觸的畫筆對象。
            drawInk(ri.ink, recognizedStrokePaint);
            //計算每個識別筆觸的邊界框。computeBoundingBox 方法根據筆觸的坐標計算出一個矩形 (Rect)，這個矩形包圍了筆觸的所有點。
            final Rect bb = computeBoundingBox(ri.ink);
            //在計算出的邊界框 (bb) 中繪製識別出的文本 (ri.text)。這裡使用 textPaint 來設置文本的繪製樣式。
            drawTextIntoBoundingBox(ri.text, bb, textPaint);
        }
        //調用 invalidate() 方法來標記視圖需要重繪。這個方法會觸發 onDraw 方法的調用，重新渲染視圖的內容，以顯示最新的筆觸和文本。
        invalidate();
    }

    //用於將文本繪製到指定的邊界框 (Rect) 中。這個方法會根據邊界框的尺寸調整文本的大小和縮放比例，以確保文本適合在邊界框內顯示。
    private void drawTextIntoBoundingBox(String text, Rect bb, TextPaint textPaint) {
        //設定一個任意的固定文本大小，這個大小用來初步估算文本的高度。20.f 是一個浮點數常量。
        final float arbitraryFixedSize = 20.f;
        // Set an arbitrary text size to learn how high the text will be.
        //設定 textPaint 的文本大小為 arbitraryFixedSize。這個大小用來計算文本的初步高度。
        textPaint.setTextSize(arbitraryFixedSize);
        //設定文本的水平縮放比例為 1.f，這表示沒有縮放。
        textPaint.setTextScaleX(1.f);

        // Now determine the size of the rendered text with these settings.
        //創建一個新的 Rect 對象 r，用來存儲文本的邊界。
        Rect r = new Rect();
        //獲取文本 text 的邊界，並將結果存儲在 r 中。這個方法會更新 r，使其包含文本的寬度和高度。
        textPaint.getTextBounds(text, 0, text.length(), r);

        // Adjust height such that target height is met.
        //根據邊界框的高度 (bb.height()) 和文本的實際高度 (r.height()) 計算所需的文本大小 (textSize)，以確保文本在垂直方向上適合邊界框。
        float textSize = arbitraryFixedSize * (float) bb.height() / (float) r.height();
        //設定 textPaint 的文本大小為計算出來的 textSize。
        textPaint.setTextSize(textSize);

        // Redetermine the size of the rendered text with the new settings.
        //再次獲取文本的邊界，以更新 r，這次使用新的文本大小。
        textPaint.getTextBounds(text, 0, text.length(), r);

        // Adjust scaleX to squeeze the text.
        //設定文本的水平縮放比例 (textScaleX)。這樣可以確保文本在水平方向上適合邊界框。這個比例是邊界框的寬度 (bb.width()) 與文本的實際寬度 (r.width()) 的比值。
        textPaint.setTextScaleX((float) bb.width() / (float) r.width());

        // And finally draw the text.
        //使用 drawCanvas 對象將文本繪製到邊界框中。文本會被繪製到 bb 的左邊 (bb.left) 和底部 (bb.bottom) 的位置。textPaint 用來設定文本的樣式和顯示效果。
        drawCanvas.drawText(text, bb.left, bb.bottom, textPaint);
    }

    //用於繪製 Ink 對象中的所有筆觸。這個方法遍歷 Ink 對象中的每個筆觸，並使用提供的 Paint 對象來進行繪製。
    private void drawInk(Ink ink, Paint paint) {
        //使用增強型 for 迴圈遍歷 ink 對象中的每個 Stroke 對象。ink.getStrokes() 返回一個包含所有筆觸的集合。
        for (Ink.Stroke s : ink.getStrokes()) {
            //對每個 Stroke 對象 s 調用 drawStroke 方法，並將 paint 對象傳遞給它。drawStroke 方法負責實際的繪製工作，根據提供的 Paint 進行繪製。
            drawStroke(s, paint);
        }
    }

    //用於繪製 Ink.Stroke 對象。這個方法將筆觸的點轉換為路徑 (Path)，並使用指定的 Paint 對象來繪製這條路徑。
    private void drawStroke(Ink.Stroke s, Paint paint) {
        Log.i(TAG, "drawstroke");
        //創建一個 Path 變量 path，並初始化為 null。Path 對象用於描述繪製的路徑。
        Path path = null;
        //使用增強型 for 迴圈遍歷 Ink.Stroke 對象中的每個點 (Ink.Point 對象)。s.getPoints() 返回一個包含所有點的集合。
        for (Ink.Point p : s.getPoints()) {
            //檢查 path 是否為 null。這是為了初始化 Path 對象，因為我們需要在開始繪製路徑之前創建一個新的 Path 對象。
            if (path == null) {
                //如果 path 為 null，創建一個新的 Path 對象。
                path = new Path();
                //使用 moveTo 方法將路徑的起點設置為當前點的坐標 (p.getX() 和 p.getY())。這表示路徑的開始位置。
                path.moveTo(p.getX(), p.getY());
            } else {
                //如果 path 已經被初始化，使用 lineTo 方法將路徑連接到當前點的坐標。這表示從上個點到當前點繪製一條直線。
                path.lineTo(p.getX(), p.getY());
            }
        }
        //使用 drawCanvas 對象將 path 繪製到畫布上。paint 用來設置繪圖的樣式（例如顏色和筆觸寬度）。
        drawCanvas.drawPath(path, paint);
    }

    //用於清除當前的繪圖內容並重置畫布。
    public void clear() {
        //調用 currentStroke 的 reset() 方法來重置筆觸。
        currentStroke.reset();
        //調用 onSizeChanged 方法來重新初始化畫布。onSizeChanged 是一個回調方法，它會在視圖的尺寸改變時被調用。在這裡，我們顯式地調用它來重新初始化畫布，這樣可以清除當前的畫布內容。
        onSizeChanged(
                canvasBitmap.getWidth(),
                canvasBitmap.getHeight(),
                canvasBitmap.getWidth(),
                canvasBitmap.getHeight());
    }

    //用於在自定義視圖中繪製內容。這個方法會在每次視圖需要重繪時被調用，它的作用是將畫布上的內容更新到屏幕上。
    @Override
    protected void onDraw(Canvas canvas) {
        //使用 canvas.drawBitmap 方法將 canvasBitmap 繪製到 canvas 上。
        //canvasBitmap 是一個 Bitmap 對象，包含了畫布的圖像數據。
        //0, 0 是 canvasBitmap 在 canvas 上的繪製起點（左上角），表示圖像的左上角會放置在畫布的左上角。
        //canvasPaint 是用於繪製 Bitmap 的 Paint 對象。這個 Paint 可以用來設置繪製效果，比如顏色、透明度等（在這裡它可能只是用來處理一些繪製效果，如反鋸齒）。
        canvas.drawBitmap(canvasBitmap, 0, 0, canvasPaint);
        //使用 canvas.drawPath 方法將 currentStroke 繪製到 canvas 上。
        //currentStroke 是一個 Path 對象，表示當前筆觸的路徑。
        //currentStrokePaint 是用於繪製 Path 的 Paint 對象，設置了筆觸的顏色、寬度等屬性。
        canvas.drawPath(currentStroke, currentStrokePaint);
    }

    //用於處理用戶的觸控事件。這是 Android 的 View 類中的一個重要方法，用於捕獲並響應觸控操作。該方法根據觸控事件的不同階段（如按下、移動、放開）來更新當前筆觸的路徑，並將其繪製到畫布上。
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        //獲取觸控事件的動作類型，getActionMasked() 方法返回一個整數，表示事件的主要動作（例如按下、移動、放開等）。這個方法可以處理多點觸控事件，提供了一個“掩碼”動作類型。
        int action = event.getActionMasked();
        //獲取觸控事件在 X 軸上的坐標。
        float x = event.getX();
        //獲取觸控事件在 Y 軸上的坐標。
        float y = event.getY();

        //根據 action 變數的值，進行不同的操作。
        switch (action) {
            case MotionEvent.ACTION_DOWN: //當手指按下屏幕時觸發：
                //將 currentStroke 的起點設置為手指按下的位置 (x, y)。
                currentStroke.moveTo(x, y);
                break;
            case MotionEvent.ACTION_MOVE: //當手指在屏幕上移動時觸發：
                //將 currentStroke 的路徑擴展到手指當前的位置 (x, y)。這樣可以連續地繪製筆跡。
                currentStroke.lineTo(x, y);
                break;
            case MotionEvent.ACTION_UP: //當手指從屏幕上抬起時觸發：
                //將 currentStroke 的路徑擴展到手指放開的位置 (x, y)。
                currentStroke.lineTo(x, y);
                //將 currentStroke 的路徑繪製到畫布上，使用指定的 currentStrokePaint。
                drawCanvas.drawPath(currentStroke, currentStrokePaint);
                //重置 currentStroke，準備開始下一個筆觸。
                currentStroke.reset();
                break;
            default:
                break;
        }
        //將當前的觸控事件添加到 strokeManager 中。這可能是用來管理和記錄筆觸事件。
        strokeManager.addNewTouchEvent(event);
        //標記視圖需要重繪。這會觸發 onDraw 方法，將當前的筆觸繪製到畫布上。
        invalidate();
        //表示已經處理了觸控事件。這樣，事件將不會傳遞給其他視圖或控件。
        return true;
    }

    @Override
    public void onContentChanged() {
        //重新繪製視圖的內容。這個方法的作用是清除畫布並重新繪製所有內容，通常用於在視圖的內容發生變化後，刷新顯示的內容。
        redrawContent();
    }
}
