package com.google.mlkit.samples.vision.digitalink;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.annotation.VisibleForTesting;


/**
 * Main activity which creates a StrokeManager and connects it to the DrawingView.
 */
public class DigitalInkMainActivity extends AppCompatActivity {
    @VisibleForTesting
    final StrokeManager strokeManager = new StrokeManager();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_digital_ink_main);
        DrawingView drawingView = findViewById(R.id.drawing_view);
        drawingView.setStrokeManager(strokeManager);
        strokeManager.setContentChangedListener(drawingView);
        strokeManager.setClearCurrentInkAfterRecognition(true);
        strokeManager.setTriggerRecognitionAfterInput(false);
        strokeManager.reset();
    }

    public void recognizeClick(View v) {
        strokeManager.recognize();
    }
}
